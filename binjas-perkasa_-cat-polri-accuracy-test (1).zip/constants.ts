
export const TOTAL_ROUNDS = 10;
export const ROUND_DURATION_SECONDS = 60;
export const BREAK_DURATION_SECONDS = 15;
export const EXAMPLE_TEMPLATES = ["MAV5G", "T2NB9", "F7KPL", "X39TG", "RQZ6B", "L0MN2", "W7RVA", "KJH3Q", "9AZX2", "MB7CQ"];
export const NUM_QUESTIONS_PER_ROUND = 50;
export const NUM_OPTIONS = 5;
